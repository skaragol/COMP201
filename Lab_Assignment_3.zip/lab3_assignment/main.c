#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>


char *strlwr(char *str)
{
    unsigned char *p = (unsigned char *)str;

    while (*p)
    {
        *p = tolower((unsigned char)*p);
        p++;
    }

    return str;
}


//10 pts
/*
 * DO NOT USE any string functions
 * You can only use strlen()
 * replace first n characters of str1[] with '*'
 * string length will be > n
 * Example: occludeStr("Efehan", 3) = "***han"
 */
char* occludeStr(char str1[], int n)
{
// Your code here
}



//20 pts
/* Find number of occurrences of word str1 in the sentence str2 (not case sensitive)
 * Returns 0 if not found
 * For Example: numOccur( "WE", "We few, we happy few, we band of brothers") = 3
 * YOU MAY USE ANY STRING FUNCTION
 */
int numOccur(char str1[] ,char str2[])
{
// Your code here

}

//20pts
/* Find the max occuring char in str (case sensitive) you may use strlwr function defined above
 * For Example: maxOccurChar("We few, we happy few, we band of brothers") = 'e'
 * Do not count whitespaces.
 * DO NOT USE any string functions
 * You can only use strlen()
 */
char maxOccurChar(char str[])
{
// Your code here

}


//20pts
/*
 * Complete "removeBlanks" function to remove extra spaces blanks from string str1.
 * return str2, which is the same string str1 without extra spaces(str2 is defined as an input argument, simply just use it).
 * EXAMPLE:
 * input  : "He dreamed        of eating   green   apples with worms    ."
 * output : "He dreamed of eating green apples with worms."
 */

char * removeBlanks(char str1[], char str2[]){
// Your code here
}


//30 pts
/*
 * Modify the given string so that vowels of the strings are reversed
 * Rest of the string has to stay as it was
 * E.g. hello -> holle
 *      Computer -> Cemputor
 * You may use strlen and strchr here
 * Do not use any other string functions
 *
 */
char *reverseVowels(char str1[]){
// Your code here
}


int main()
{

    int score = 0;

    char str5[100];
    char str6[] = "He dreamed  of eating   green   apples with     worms\0";

    char str9[] = "Efehan\0";
    char str10[] = "Hello World\0";

    char str11[] = "leads";
    char str12[] = "Fear leads to anger anger leads to hatred hatred leads to conflict conflict leads to suffering";
    char str13[] = "Leads";
    char str14[] = "Fear LEADS to anger anger Leads to hatred hatred leadS to conflict conflict leads to suffering";
    char str15[] = "possible";
    char str16[] = "This is impossible";
    char str17[] = "pasta";

    char str18[] = "destination";
    char str19[] = "Euouae";


// occludeStr test cases
    if (strcmp(occludeStr(str9, 3), "***han") == 0)
    {

        printf("occludeStr test1 passed!\n");
        score +=5;
    }
    else{
        printf("occludeStr test1 failed!\n");
    }

    if (strcmp(occludeStr(str10, 5), "***** World") == 0)
    {

        printf("occludeStr test2 passed!\n");
        score +=5;
    }
    else{
        printf("occludeStr test2 failed!\n");
    }


// numOccur test cases
    if (numOccur(str11, str12) == 4)
    {
        printf("numOccur test1 passed!\n");
        score +=10;
    }
    else{
        printf("numOccur test1 failed!\n");
    }

    if (numOccur(str13, str14) == 4)
    {
        printf("numOccur test2 passed!\n");
        score +=5;
    }
    else{
        printf("numOccur test2 failed!\n");
    }

    if (numOccur(str17, str14) == 0)
    {
        printf("numOccur test3 passed!\n");
        score +=5;
    }
    else{
        printf("numOccur test3 failed!\n");
    }

// maxOccurChar test case
    if(maxOccurChar("Fear leads to anger anger leads to hatred hatred leads to conflict conflict leads to suffering") == 'e')
    {
        printf("maxOccur test passed!\n");
        score +=20;
    }
    else
    {
        printf("maxOccur test failed!\n");
    }

// Remove blanks

    if (strcmp(removeBlanks("ketchup    recipe\0", str5), "ketchup recipe\0")==0){
        printf("removeBlanks test1 passed!\n");
        score +=10;
    }
    else{
        printf("removeBlanks test1 failed!\n");
    }

    if (strcmp(removeBlanks(str6, str5), "He dreamed of eating green apples with worms\0")==0){
        printf("removeBlanks test2 passed!\n");
        score +=10;
    }
    else{
        printf("removeBlanks test2 failed!\n");
    }

// reverse vowels test cases
    reverseVowels(str15);

    if(!strcmp(str15,"pessiblo"))
    {
        printf("reverseVowels test passed!\n");
        score +=10;
    }
    else
    {
        printf("reverseVowels test failed!\n");
    }

    reverseVowels(str18);

    if(!strcmp(str18,"dostinatien"))
    {
        printf("reverseVowels test passed!\n");
        score +=10;
    }
    else
    {
        printf("reverseVowels test failed!\n");
    }

    reverseVowels(str19);

    if(!strcmp(str19,"eauouE"))
    {
        printf("reverseVowels test passed!\n");
        score +=10;
    }
    else
    {
        printf("reverseVowels test failed!\n");
    }

    printf("This user's score is: %d\n",score);

    return 0;

}
